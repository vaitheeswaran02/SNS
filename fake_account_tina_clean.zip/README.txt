CLEAN TINA PETRI-NET SIMULATION

This version intentionally uses ONE token only. It models the fake-account
workflow as a deterministic demonstration:

Account_Created
 -> Profile_Analysis
 -> Profile_Analyzed
 -> Behaviour_Analysis
 -> Behaviour_Analyzed
 -> Bot_Detection_Check
 -> Bot_Detection
 -> Classify_Fake
 -> Fake_Account

1. Extract this folder into ~/Downloads.
2. Run:
   cd ~/Downloads/tina-4.0.0
   ./bin/ndrio -graphplace ~/Downloads/fake_account_tina_clean/fake_account_detection_clean.net ~/Downloads/fake_account_tina_clean/fake_account_detection_clean.ndr
   ./bin/nd ~/Downloads/fake_account_tina_clean/fake_account_detection_clean.ndr

3. In nd, open Tools -> stepper simulator.
4. The initial token is in Account_Created.
5. Use the forward step button (>) once per transition. The token moves through
   all states and ends in Fake_Account.
6. To load the deterministic history, use the stepper's File -> Load Scenario
   and select:
   ~/Downloads/fake_account_tina_clean/fake_account_detection_clean.scn

7. Command-line simulation:
   cd ~/Downloads/tina-4.0.0
   ./bin/play ~/Downloads/fake_account_tina_clean/fake_account_detection_clean.net
   Then enter the four 'f' commands from run_fake_simulation.txt.

TINA's nd stepper is a step-by-step simulator. The official documentation
describes '>' as redo/advance in history and .scn as a firing sequence/history.
There is no claim here that one GUI click creates continuous animation.
