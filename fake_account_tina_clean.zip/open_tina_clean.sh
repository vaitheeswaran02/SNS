#!/bin/bash
set -e
TINA="$HOME/Downloads/tina-4.0.0"
BASE="$HOME/Downloads/fake_account_tina_clean"
"$TINA/bin/ndrio" -graphplace "$BASE/fake_account_detection_clean.net" "$BASE/fake_account_detection_clean.ndr"
"$TINA/bin/nd" "$BASE/fake_account_detection_clean.ndr"
